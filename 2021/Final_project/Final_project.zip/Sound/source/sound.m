[s fs] = audioread('E:\\Digipen\\PHY250\\2021\\Homeworks\\Final_project\\Sound\\source\\Violin.pizz.ff.sulG.G3.stereo.wav');
#s=s/max(abs(s));
trans=abs(fft(s));
L=length(trans)
spectrum=trans(1:L/2);

Ls=length(spectrum)
spectrum=spectrum/max(spectrum);
frequencies=fs*(1:(L/2))/L;
Lf=length(frequencies)


n=length(s);
t=n/fs;
Ts=1/fs;
time=[0:Ts:(t-Ts)];
figure

A=zeros(1,7);
#{
#ARC
A(1)=0.1
A(2)=1
A(3)=0.52
A(4)=0.18
A(5)=0.04
A(6)=0.11
A(7)=0.08

f=200
#}

##{
#Pizz
A(1)=0.3
A(2)=1
A(3)=0.7
A(4)=0.37
A(5)=0.31
A(6)=0.25
A(7)=0.11

f=200
#}

[frequencies_sim,signal_sim]=simulation(A,f,fs,n);
  
subplot(2,1,1)
plot(time,s,'b')
hold on
plot(time,signal_sim,'r');

axis([0.4 0.5 -1 1])
hold off
title(['Signal']);
xlabel('time(s)')
ylabel('Amplitude')

subplot(2,1,2)

plot(frequencies,spectrum)
hold on
bar(frequencies_sim,A,0.01)
axis([0 2000 0 1])
hold off
title(['Spectrum']);
xlabel('Frequencies (HZ)')
ylabel('Amplitude')


