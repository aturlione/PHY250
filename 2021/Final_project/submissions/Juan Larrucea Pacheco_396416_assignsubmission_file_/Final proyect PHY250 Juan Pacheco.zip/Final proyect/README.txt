The code you have to correct is in the SHADER CODE folder

Demo notes:
-You can select between the objects in the left list
-Relevant parts: 
	->If you select the first object (the PBR one), you can change the material properties.
	For that, once selected, check in the right list and click in light receiver to expand it.
	There you will find a modulation color, a list with all the meshes to try, a checkbox to see the
	sphere with textures and three parameters, the roughness, the metallicness and the ambient oclussion.
	
	->If you select the skybox (last item), and once selected you expand equirectangular skybox (in the left list), you can change
	between three available skyboxes