function Waves
  #I don't have the code for the fluid, but I can answer the questions
  
  #So, an incompressible, non-viscous, circulation-free liquid
  #Is a fluid whose density doesn't chang with pressure, which has no 
  #internal frictional force between adjacent layers of the fluid and runs
  #along a surface with no restrictions at all.
  
  #This fluid's velocity is bidimensional (it has X and Y component) and
  #it isn't constant along the areas perpendicular to the fluid, contrary to 
  #the ones in the exercises, which only have a X component and they are constant
  #along perpendicular areas, which simplified the problems a lot and we could use
  #The formulas given in class.
  
  #Since this fluid isn't constant along the areas perpendicular to the fluid, 
  #We can't state the colume flow rate is "V * a". So, in order to compute the
  #Volume rate of this fluid, we should take into account the surface the fluid 
  #it flows and integrate it so we can know what's the velocity in each part of the surface.
  
endfunction 