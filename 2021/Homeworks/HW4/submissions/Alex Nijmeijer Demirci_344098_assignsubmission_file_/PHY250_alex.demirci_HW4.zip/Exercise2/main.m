%Alex Demirci
%Main function, lets you choose wich part of thetaticks
%excercise to execute

function main

  option = menu('Excercise2', 'A', 'B', 'C','Exit');
 
  if option == 1
      a;
  elseif option == 2
      b;
  elseif option == 3;
      c;
  elseif 
      close;
  endif;
  
endfunction