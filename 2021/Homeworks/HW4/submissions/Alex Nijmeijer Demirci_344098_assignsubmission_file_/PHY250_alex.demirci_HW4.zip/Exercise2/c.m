%Alex Demirci
%Simulates the motion of a SHO and damped
% motion with an external force applied

function c
  
 
  
 endfunction